<?php
require_once AWESOME_SERVICES_PATH . 'awesome-services-main.php';
function carolina_display_repeater_data_shortcode() {
    $post_id = get_the_ID();

    if ( ! $post_id ) {
        return ''; 
    }

    $repeater_data = get_post_meta( $post_id, '_list_repeater', true );
    if ( empty( $repeater_data ) || ! is_array( $repeater_data ) ) {
        return '';
    }

    $output = '';
    $has_items = false;
    if ( isset( $repeater_data['da_list_repeater_row_count'] ) && $repeater_data['da_list_repeater_row_count'] > 0 ) {
        for ( $index = 0; $index < $repeater_data['da_list_repeater_row_count']; $index++ ) {
            $item_key = "da_list_repeater[{$index}][item]";
            if ( isset( $repeater_data[ $item_key ] ) && ! empty( $repeater_data[ $item_key ] ) ) {
                $has_items = true;
                break; 
            }
        }
    }
    if ( ! empty( $repeater_data['da_list_title'] ) || $has_items ) {
        if ( ! empty( $repeater_data['da_list_title'] ) ) {
            $output .= '<h3>' . esc_html( $repeater_data['da_list_title'] ) . '</h3>';
        }
        if ( $has_items ) {
            $output .= '<ul>';
            for ( $index = 0; $index < $repeater_data['da_list_repeater_row_count']; $index++ ) {
                $item_key = "da_list_repeater[{$index}][item]";
                if ( isset( $repeater_data[ $item_key ] ) && ! empty( $repeater_data[ $item_key ] ) ) {
                    $output .= '<li>' .  $repeater_data[ $item_key ]  . '</li>';
                }
            }
            $output .= '</ul>';
        }
    }
    return $output;
}
add_shortcode( 'dibraco_display_repeater_data', 'carolina_display_repeater_data_shortcode' );



function dibraco_location_map_shortcode($atts) {
    $atts = shortcode_atts([
        'view'      => 'normal',
        'loc'       => '',
        'width'     => '100%',
        'height'    => '400px',
        'max_width' => '600px'
    ], $atts, 'dibraco_location_map');

    $view_type = $atts['view'];
    $location_slug = $atts['loc'];
    $post_id = get_the_ID();

    if (!$post_id) {
        return '';
    }

    $map_data = [];
    $keys = ['street_address', 'street_address_2', 'city', 'state', 'zipcode', 'addy_country', 'latitude', 'longitude', 'place_id'];
    $location_term_id = da_get_location_term_or_default($post_id, $location_slug);

    if ($location_term_id) {
        $name_key = 'location_name';
        $keys[] = $name_key;
        foreach ($keys as $key) {
            $map_data[$key] = get_term_meta($location_term_id, $key, true);
        }
    } else {
        $name_key = 'name';
        $keys[] = $name_key;
        $company_info = get_option('company_info');
        if (!empty($company_info)) {
            foreach ($keys as $key) {
                $map_data[$key] = $company_info[$key];
            }
        }
    }
    if (empty(array_filter($map_data))) {
        return '';
    }
    $address_parts = [
        $map_data[$name_key],
        $map_data['street_address'],
        $map_data['street_address_2'],
        $map_data['city'],
        $map_data['state'],
        $map_data['zipcode']
    ];
    $address_query = implode(', ', array_filter($address_parts));
    $coords_query = '';
    if (!empty($map_data['latitude']) && !empty($map_data['longitude'])) {
        $coords_query = $map_data['latitude'] . ',' . $map_data['longitude'];
    }
    $map_embed_src = '';
    switch ($view_type) {
        case 'street':
            if ($coords_query) {
                $streetview_params = [
                    'q'      => $address_query ?: $coords_query,
                    'cbll'   => $coords_query,
                    'cbp'    => '12,235,,0,5',
                    'layer'  => 'c',
                    'output' => 'svembed'
                ];
                $map_embed_src = 'https://maps.google.com/maps?q=' . http_build_query($streetview_params);
            }
            break;
        case 'satellite':
        case 'normal':
        default:
            $location_query = $address_query ?: $coords_query;
            if ($location_query) {
                $base_url = 'https://maps.google.com/maps?q=' . urlencode($location_query);
                $map_type_param = ($view_type === 'satellite') ? '&t=k' : '';
                $map_embed_src = $base_url . '&z=14' . $map_type_param . '&output=embed';
            }
            break;
    }

    if (empty($map_embed_src)) {
        return '';
    }
    $iframe_style = sprintf(
        'style="width: %s; height: %s; max-width: %s; border: 0;"',
        esc_attr($atts['width']),
        esc_attr($atts['height']),
        esc_attr($atts['max_width'])
    );

    $iframe_html = '<div class="dibraco-location-map"><iframe src="' . esc_url($map_embed_src) . '" ' . $iframe_style . ' allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></div>';
    return $iframe_html;
}
add_shortcode('dibraco_location_map', 'dibraco_location_map_shortcode');

function dibraco_get_processed_context_data($context_name) {
    $enabled_contexts = get_option('enabled_contexts');
    if (!isset($enabled_contexts[$context_name])) {
        return []; 
    }
    
    $context_data = $enabled_contexts[$context_name];
    $context_type = $context_data['context_type'];
    $context_name = $context_data['context_name'];
    $status = get_option('locations_areas_status');
    $card_style_settings = '';
    $current_post_id = get_the_ID();
    return get_the_context_by_status($context_type, $context_name, $context_data, $current_post_id, $status, $card_style_settings);
}
function dibraco_display_related_posts_list($atts) {
    $atts = shortcode_atts(['context' => 'main_service', 'bullets' => 'yes'], $atts);
    $cards = dibraco_get_processed_context_data($atts['context']);
    if (empty($cards)) {
        return 'No related posts found.';
    }
    $listStyle = ($atts['bullets'] === 'no') ? 'style="list-style-type: none;"' : '';
    $output = '<ul ' . $listStyle . '>';
    foreach ($cards as $card) {
        $output .= '<li><a href="' . esc_url($card['related_post_url']) . '">' . esc_html($card['related_post_title']) . '</a></li>';
    }
    $output .= '</ul>';
    return $output;
}
add_shortcode('da_related_posts_list', 'dibraco_display_related_posts_list');


function dibraco_display_related_list_comma($atts) {
      $atts = shortcode_atts([
        'context' => 'main_service', 
        'separator'    => ',' 
    ], $atts, 'da_related_list_comma');
    $cards = dibraco_get_processed_context_data($atts['context']);
$separator = $atts['separator'];
    if (empty($cards)) {
        return 'No related posts found.';
    }

    $output = '';
    $total_items = count($cards);
   foreach($cards as $index => $post_data){
      $the_title = $post_data['related_post_title'];
      $related_link = $post_data['related_post_url'];

        $output .= '<a href="' . esc_url($related_link) . '" title="Read more about ' . esc_attr($the_title) . '" aria-label="Read more about ' . esc_attr($the_title) . '">' . esc_html($the_title) . '</a>';
            if ($index < $total_items - 2) {
            $output .= $separator . ' ';
        } elseif ($index == $total_items - 2) {
            $output .= $separator . ' and ';
        }
    }

    return $output;
}
add_shortcode('da_related_list_comma', 'dibraco_display_related_list_comma');
function dibraco_enqueue_frontend_styles() {
    wp_register_style(
        'da-photo-hover-style', 
        AWESOME_SERVICES_URL . 'front-end-css/da-photo-hover.css', 
        [], 
        '1.0' 
    );
}
add_action('wp_enqueue_scripts', 'dibraco_enqueue_frontend_styles');

function da_related_photo_hover_shortcode($atts) {
    $attributes = shortcode_atts(['context' => 'main_service'], $atts); 
    $cards = dibraco_get_processed_context_data($attributes['context']);
    if (empty($cards)) return 'No related posts found.';
    wp_enqueue_style('da-photo-hover-style');
    $output = '<div class="da-related-photo-hover-container">';
    shuffle($cards);
    $enabled_contexts = get_option('enabled_type_contexts');
    $context_config = $enabled_contexts[$attributes['context']];
    foreach ($cards as $card) {
        $post_id = $card['related_post_id'];
        $related_link = $card['related_post_url'];
        $display_text = $card['related_post_title'];
        $image_options = [];
        if ($context_config['repeater_images'] === '1') {
            $img1 = get_post_meta($post_id, 'dibraco_landscape_1', true);
            $img2 = get_post_meta($post_id, 'dibraco_landscape_2', true);
            if (!empty($img1)) $image_options[] = wp_get_attachment_url($img1);
            if (!empty($img2)) $image_options[] = wp_get_attachment_url($img2);
        }
        $featured_img = get_the_post_thumbnail_url($post_id, 'full');
        if (!empty($featured_img)) $image_options[] = $featured_img;
        $final_img = esc_url($image_options ? $image_options[array_rand($image_options)] : '');
        $output .= '<a href="' . esc_url($related_link) . '" class="da-related-photo-link" aria-label="' . esc_attr($display_text) . '" title="' . esc_attr($display_text) . '">';
        $output .= '<img src="' . $final_img . '" alt="' . esc_attr($display_text) . '">';
        $output .= '<div class="da-related-photo-title">' . esc_html($display_text) . '</div>';
        $output .= '</a>';
    }
    $output .= '</div>';
    return $output;
}
add_shortcode('da_related_photo_hover', 'da_related_photo_hover_shortcode');

