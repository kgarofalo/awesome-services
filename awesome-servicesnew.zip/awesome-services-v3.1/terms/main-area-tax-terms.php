<?php

function display_service_area_term_fields($term, $service_areas_tax, $area_connector_context) {
    $current_service_area_term_id = $term->term_id;
    $current_service_area_term_name = $term->name;
    $city = get_term_meta($current_service_area_term_id, 'city', true) ?: $current_service_area_term_name;
    $state = get_term_meta($current_service_area_term_id, 'state', true);
    $latitude =  get_term_meta($current_service_area_term_id, 'latitude', true);
    $longitude =  get_term_meta($current_service_area_term_id, 'longitude', true);
    if (empty($state)) {
        $status = get_option('locations_areas_status');
        if ($status === 'both') {
            $area_parent_location_term = get_term_meta($current_service_area_term_id, 'area_parent_location_term', true);
            if (!empty($area_parent_location_term)) {
                $state = get_term_meta($area_parent_location_term, 'state', true);
            }
        }
    }
    if (empty($state)) {
        $state = get_option('company_info')['state'];
    }
    $service_area_link_url = get_term_meta($current_service_area_term_id, 'service_area_link_url', true) ?? '';
    $service_area_fields = [
        'city'      => ['type' => 'text', 'value' => $city],
        'state'     => ['type' => 'text', 'value' => $state],
        'latitude'  => ['type' => 'text', 'value' => $latitude],
        'longitude' => ['type' => 'text', 'value' => $longitude],
    ];
      
?>
<table class="striped widefat fixed term-address-details-wrap">
<?php wp_nonce_field('save_service_area_term', 'custom_fields_nonce'); ?>
    <tr> <td> <div style="display: flex; flex-wrap: wrap;">
                <?php foreach ($service_area_fields as $field_name => $field_config) {
                 echo FormHelper::generateField($field_name, $field_config);  }?>
            </div> <p class="description">Enter City, State, Latitude, and Longitude for this Service Area. Latitude/Longitude can be <a href="#" class="dibraco-fetch-geo-from-city-state" style="cursor:pointer;">fetched from City/State</a> if left blank and City/State are filled.</p>
            <p style="font-weight: bold; margin-bottom: 5px;">Service Area Connector URL:</p>
            <input type="text" value="<?= $service_area_link_url ?>" class="dibraco-text" readonly style="width: 100%; box-sizing: border-box; background-color:lightgrey;">
        </td> </tr></table>
<?php    
$related_unique_contexts = $area_connector_context['related_unique_contexts'];
if (!empty($related_unique_contexts)){
render_related_unique_context_tables($related_unique_contexts, $current_service_area_term_id);
}
$related_type_contexts = $area_connector_context['related_type_contexts'];
if (!empty($related_type_contexts)){
render_related_type_context_tables($related_type_contexts, $current_service_area_term_id);
}
}

function handle_save_service_area_term_related_types($term_id, $submitted_data, $area_connector_context) {
if (!dibraco_verify_post_save_request('custom_fields_nonce', 'save_service_area_term')) {return;}
    $city = $submitted_data['city'] ?? '';
    $state = $submitted_data['state'] ?? '';
    $latitude = $submitted_data['latitude'] ?? '';
    $longitude = $submitted_data['longitude'] ?? '';
    update_term_meta($term_id, 'city', $city);
    update_term_meta($term_id, 'state', $state);
    $service_area_taxonomy = $area_connector_context['taxonomy'];
    $service_area_post_type = $area_connector_context['post_type'];
    if (($latitude ==='' && $longitude === '') && ($city!=='' && $state !=='')) {
        $lat_long = get_lat_long_from_osm_2('', $city, $state, '');
        if ($lat_long && isset($lat_long['lat']) && isset($lat_long['long'])) {
            $latitude = $lat_long['lat'];
            $longitude = $lat_long['long'];
        }
    update_term_meta($term_id, 'latitude', $latitude);
    update_term_meta($term_id, 'longitude', $longitude);
    }
   
     $status = get_option('locations_areas_status');
     if ($status ==='both'){
        $new_area_parent_term = $submitted_data['area_parent_location_term'];
        $current_area_parent_term = get_term_meta($term_id, 'area_parent_location_term', true);
        update_term_meta($term_id, 'area_parent_location_term', $new_area_parent_term);
     }
    $related_type_contexts = $area_connector_context['related_type_contexts'];
    if ($related_type_contexts !==[]){
    foreach ($related_type_contexts as $type_context_data) {
    $meta_key_to_save = "related_type_{$type_context_data['type_name']}";
    $post_per_term = $type_context_data['post_per_term'];
    $related_connector_count = $type_context_data['related_connector_count'];
    $current_meta_data = get_term_meta($term_id, $meta_key_to_save, true);
    if (!empty($current_meta_data)){
    $fall_back_update_flag = false; 
    if ($related_connector_count === 2){
    if (($current_area_parent_term !== $new_area_parent_term) && ($post_per_term === "1") && $new_area_parent_term !== '') {
        $fall_back_update_flag = true;
        $location_term_meta_key_data = get_term_meta($new_area_parent_term, $meta_key_to_save, true);
    }}
        if ($post_per_term === "1") {
            foreach ($submitted_data[$meta_key_to_save] as $type_term_id => $term_data_from_submission) {
                $current_meta_data[$type_term_id]['related_post_title'] = $term_data_from_submission['related_post_title'];
            if ($fall_back_update_flag === true) {
                    $new_fallback_url = $location_term_meta_key_data[$type_term_id]['related_post_url'];
                    $current_meta_data[$type_term_id]['fallback_url'] = $new_fallback_url;
                }
            }
        } else {
            foreach ($submitted_data[$meta_key_to_save] as $type_term_id => $term_posts_from_submission) {
                foreach ($term_posts_from_submission as $related_post_id => $post_data_from_submission) {
                    $current_meta_data[$type_term_id][$related_post_id]['related_post_title'] = $post_data_from_submission['related_post_title'];
                }
            }
        }
        update_term_meta($term_id, $meta_key_to_save, $current_meta_data);
    }
    }
    }
    $related_unique_contexts = $area_connector_context['related_unique_contexts'];
    if (!empty($related_unique_contexts)){
    foreach ($related_unique_contexts as $unique_context_data) {
        $meta_key_to_save_unique = "related_unique_{$unique_context_data['unique_name']}";
        $current_unique_meta_data = get_term_meta($term_id, $meta_key_to_save_unique, true);
        foreach ($submitted_data[$meta_key_to_save_unique] as $post_id => $post_data_from_submission) {
            $current_unique_meta_data[$post_id]['related_post_title'] = $post_data_from_submission['related_post_title'];
        }
        update_term_meta($term_id, $meta_key_to_save_unique, $current_unique_meta_data);
    }
}
}
function render_service_area_custom_meta_box($post, $metabox_args) {
    $context_data = $metabox_args['args']['context_data'];
    $taxonomySlug = $context_data['taxonomy'];
    $contact_fields = $context_data['contact_section'];
    $dibraco_banner = $context_data['dibraco_banner'];
    $main_sections = $context_data['main_sections'];
   
    $termId = dibraco_get_current_term_id_for_post($post->ID, $taxonomySlug);
    $term_obj = get_term($termId, $taxonomySlug);
    $termFields = [];
    $fields = [];
    if ($dibraco_banner === "1") {
        $banner_fields = get_banner_fields();
        $fields_to_render[] = [
            'da_main_h1' => $banner_fields['da_main_h1'],
            'da_banner_description' => $banner_fields['da_banner_description']
        ];
    }
    if ($main_sections === "1" ) {
        $main_sec_fields =  get_section_title_fields('service_areas');
         $fields_to_render[] = [
            'about_title' => $main_sec_fields['about_title'],
            'about_blurb' => $main_sec_fields['about_blurb']
        ];
         $fields_to_render[] = [
            'da_section_1_title' => $main_sec_fields['da_section_1_title'],
            'da_section_1_p' => $main_sec_fields['da_section_1_p']
        ];
         
         $fields_to_render[] = [
            'da_section_2_title' => $main_sec_fields['da_section_2_title'],
            'da_section_2_p' => $main_sec_fields['da_section_2_p']
        ];
   
         $fields_to_render[] = [
            'da_section_3_title' => $main_sec_fields['da_section_3_title'],
            'da_section_3_p' => $main_sec_fields['da_section_3_p']
        ];
        
        $termFields = ['city', 'state', 'latitude', 'longitude']; 
    }
    if ($contact_fields === "1") {
        $contact_fields_data = get_contact_fields();
        $fields_to_render[] = [
            'da_quote_title' => $contact_fields_data['da_quote_title'],
            'da_contact_section' => $contact_fields_data['da_contact_section']
        ];
    }
    $user_defined_fields = get_dibraco_custom_fields_for_context('service_areas');

    if (!empty($user_defined_fields)) {
        $custom_field_groups = array_chunk($user_defined_fields, 2, true);
        foreach ($custom_field_groups as $group) {
            $fields_to_render[] = $group;
        }
    }
    ?>
    <div style="display:flex; flex-wrap:wrap; gap:5px;">
        <?php wp_nonce_field('save_service_area_custom_fields', 'custom_fields_nonce'); ?>
        <div style="display:flex; justify-content: space-between; width:100%;">
            <?php foreach ($termFields as $key) :
                $config = $main_sec_fields[$key];
                $config['value'] = get_term_meta($termId, $key, true); ?>
                <div style="display: flex; width: 24.5%;">
                    <?= FormHelper::generateField($key, $config); ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php
     foreach ($fields_to_render as $pair) {
        echo '<div style="width: 49%; margin-bottom: 20px;">';  // Each pair container
        foreach ($pair as $field_id => $field_config) {
            $field_config['value'] = get_post_meta($post->ID, $field_id, true);
            echo FormHelper::generateField($field_id, $field_config);
        }
        echo '</div>';  
    }
    echo '</div>';
}

function save_service_area_custom_fields($post_id, $service_area_taxonomy, $context_data) {
    if (!dibraco_verify_post_save_request('custom_fields_nonce', 'save_service_area_custom_fields')) {
        return;
    }
    $new_term_id = $_POST["{$service_area_taxonomy}_term"] ?? '';
    dibraco_enforce_one_connector_term_per_connector_post($post_id, $new_term_id, $service_area_taxonomy, 'service_area_post_id', 'service_area_link_url');

    if ($new_term_id !== '') {
        $new_term_id = (int) $new_term_id;
        $city = $_POST['city'];
        $state = $_POST['state'];
        $lat = $_POST['latitude'];
        $long = $_POST['longitude'];
        if ((!empty($city)) && (!empty($state))) {
            $lat_long = get_lat_long_from_osm_2('', $city, $state, '');
            if ($lat_long && isset($lat_long['lat']) && isset($lat_long['long'])) {
                $lat = $lat_long['lat'];
                $long = $lat_long['long'];
            }
        }
        $state_updated = update_term_meta($new_term_id, 'state', $state);
        $lat_updated = update_term_meta($new_term_id, 'latitude', $lat);
        $long_updated = update_term_meta($new_term_id, 'longitude', $long);

    }
    $user_defined_fields = get_dibraco_custom_fields_for_context('service_areas');
    if (!empty($user_defined_fields)) {
        foreach ($user_defined_fields as $field_id => $field_config) {
       update_post_meta($post_id, $field_id, sanitize_textarea_field($_POST[$field_id]));
        }
    }
    if ($context_data['main_sections'] === "1") {
        $main_sec_fields = get_section_title_fields('service_areas');
        $term_keys_to_skip = ['city', 'state', 'latitude', 'longitude']; 
        foreach ($main_sec_fields as $field_key => $field_value) {
              if (!in_array($field_key, $term_keys_to_skip)) {
            update_post_meta($post_id, $field_key, $_POST[$field_key]);
              }
        }
    }

    if ($context_data['contact_section'] === "1") {
        $contact_fields_data = get_contact_fields();
        foreach ($contact_fields_data as $field_key => $field_value) {
            update_post_meta($post_id, $field_key, $_POST[$field_key]);
        }
    }
    if ($context_data['dibraco_banner'] === "1") {
        $banner_fields = get_banner_fields();
        foreach ($banner_fields as $field_key => $field_value) {
            update_post_meta($post_id, $field_key, $_POST[$field_key]);
        }
    }
}


